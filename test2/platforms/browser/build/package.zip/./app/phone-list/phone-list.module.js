'use strict';

// Define the `phoneList` module
angular.module('phoneList', []);
